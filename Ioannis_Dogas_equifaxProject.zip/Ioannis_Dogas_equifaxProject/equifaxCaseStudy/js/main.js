"use strict";

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~form validation */


/*aquire inputs for validation*/
var $username = $("#username");
var $userMail = $("#userMail");
var $userMailRepeat = $("#userMailRepeat");


/*mathes special characters and numbers*/
var textPattern = /\W+|\d+/g;

/*email regular expression*/
var emailPattern =/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;



/*hide evaluation hint*/

$("form span").hide();

/*compare text to regex*/

function textValidity() {
    return $username.val().match(textPattern);
}

/*if text has correct format hide hint else show it*/

function textCheck() {    
    if (!textValidity()) {        
        $username.next().hide();
    } else {       
        $username.next().show();
    }
}

/*$username.keyup(textValidity).keyup(textCheck);*/
$username.focusout(textValidity).focusout(textCheck);



/*compare mail to regex*/

function mailValidity() {
   return $userMail.val().match(emailPattern);
}

/*compare the emails */

function mailComparison() {
    return $userMail.val() === $userMailRepeat.val();
}

/*if email has correct format hide hint else show it*/

function mailCheck() {
     
    if (mailValidity()) {
        
        $userMail.next().hide();
    } else {
     
        $userMail.next().show();
    }
}


/*if emails match hide hint else show it*/
function mailMatching() {    
    if (mailComparison()) {       
        $userMailRepeat.next().hide();
    } else {   
        $userMailRepeat.next().show();
    }
}

/*validation starts on keyup at the spacific input*/

$userMail.focusout(mailCheck);
$userMailRepeat.focusout(mailMatching);


/*since no real submission is required submit button is disabled*/
$("#submit").click(function (event) {
    event.preventDefault(); 
});

