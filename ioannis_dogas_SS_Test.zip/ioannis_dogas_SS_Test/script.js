"use strict";

/*============= hotspot behaviour =====================*/


/* description bottom container variables*/

const backgroundImageContainer=document.getElementById("backgroundImageContainer");
const backgroundImageHeading=document.getElementById("backgroundImageHeading");
const backgroundImageText=document.getElementById("backgroundImageText");

/* removes the class that colors the appropriate word in the mobile version of the webpage */

function activeWordRemove() {
  let i, word;
  word = document.getElementsByClassName("word");

  for (i = 0; i < word.length; i++) {
      word[i].classList.remove("activeWord");
  }
}

//depending on which hotspot is clicked the text in the description bottom container changes and the appropriate word in the mobile version of the webpage is colored


  /* hotspot 1 */

const hotspot1=document.getElementById("hotspot1");
hotspot1.addEventListener("click", hotspot1Description);

function hotspot1Description(){

  backgroundImageContainer.style.backgroundImage = "url('images/bg-3.jpg')";
  backgroundImageHeading.innerHTML="WEAVED UPPER";
  backgroundImageText.innerHTML="A new Flyknit weave technology with an elevated fit and feel featuring a lighter and smoother experience that molds to your foot.";
  activeWordRemove();
  document.getElementById("springy").classList.add("activeWord");
}


/* hotspot 2 */

  const hotspot2=document.getElementById("hotspot2");
 hotspot2.addEventListener("click", hotspot2Description);

  function hotspot2Description(){

    backgroundImageContainer.style.backgroundImage = "url('images/bg-1.jpg')";
    backgroundImageHeading.innerHTML="QUICKER THAN A ROCKET";
    backgroundImageText.innerHTML="Okay, so maybe it's not quicker than a rocket. React gives you that instant go you need to do mile after mile, run after run.";
    activeWordRemove();
  document.getElementById("soft").classList.add("activeWord");
  }

/* hotspot 3 */

const hotspot3=document.getElementById("hotspot3");
hotspot3.addEventListener("click", hotspot3Description);

function hotspot3Description(){

  backgroundImageContainer.style.backgroundImage = "url('images/bg-2.jpg')";
  backgroundImageHeading.innerHTML="SOOOO SQUISHY";
  backgroundImageText.innerHTML="React is soft and squishy, yet responsive and stable. It gives you the cushioning you need to hit mile after mile.";
  activeWordRemove();
  document.getElementById("knitted").classList.add("activeWord");
}


  /* hotspot 4 */

  const hotspot4=document.getElementById("hotspot4");
  hotspot4.addEventListener("click", hotspot4Description);

function hotspot4Description(){

  backgroundImageContainer.style.backgroundImage = "url('images/bg-4.jpg')"; 
  backgroundImageHeading.innerHTML="JUST LIKE A KANGAROO";
  backgroundImageText.innerHTML="Ridiculously responsive. Nike React foam bounces the energy of your stride right back at you, and keeps bouncing right back at you even after hundreds of miles.";
  activeWordRemove();
  document.getElementById("go").classList.add("activeWord");
}


/* active hotspot highlight and content effect*/

// depending on the hotspot you click a border color highlights the active one and content appears with opacity effect

const hotspotArea = document.getElementById("hotspotArea");

const hotspotTag = hotspotArea.getElementsByClassName("hotspotTag");

let j;
for (j = 0; j < hotspotTag.length; j++) {
  hotspotTag[j].addEventListener("click", function() {

    let activeHotspot = document.getElementsByClassName("activeHotspot");
    activeHotspot[0].className = activeHotspot[0].className.replace(" activeHotspot", "");
    this.className += " activeHotspot"; 

    backgroundImageContainer.classList.remove("activeContent");
    backgroundImageContainer.offsetWidth;
    backgroundImageContainer.classList.add("activeContent");
  });
}


/*================ mobile webpage version behaviour ===============*/

/* word container mobile visibility */

//for viewport less than 768px the mobile version of the webpage takes place

const wordBottomContainer=document.getElementById("wordBottomContainer");
const backgroundImageTextContainer=document.getElementById("backgroundImageTextContainer");

const maxWidth = window.matchMedia("(max-width: 767px)");
maxWidth.addListener(mediaQueryMatch); 

function mediaQueryMatch(maxWidth) { 
 
  if (maxWidth.matches) {
    wordBottomContainer.classList.remove("notDisplayed");  
    backgroundImageContainer.classList.add("noBackgroundImage");
    backgroundImageTextContainer.style.color="black";    
  } else {
    wordBottomContainer.classList.add("notDisplayed");
    backgroundImageContainer.classList.remove("noBackgroundImage"); 
    backgroundImageTextContainer.style.color="white"; 
  }
}

mediaQueryMatch(maxWidth);
