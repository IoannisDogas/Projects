"use strict";

/*~~~~~~~~~~~~~~~~~~~~navigation menu */

let enjoyLogo=document.getElementById("enjoyLogo");
enjoyLogo.addEventListener("click",responsiveNav);


function responsiveNav() {
    let navMenu = document.getElementById("navMenuId");
    if (navMenu.className === "navMenu") {
      navMenu.className += " responsive";
    } else {
      navMenu.className = "navMenu";
    }
  }


